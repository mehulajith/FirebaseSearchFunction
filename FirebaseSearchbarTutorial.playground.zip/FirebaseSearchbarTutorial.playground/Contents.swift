//: Playground - noun: a place where people can play

import UIKit
import Firebase

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {

    // Main Firebase URL
    var ref = FIREBASE_URL

    // Required IBOutlets
    @IBOutlet weak var searchBar: UISearchBar!
    @IBOutlet weak var tableView: UITableView!

    // Required delegate & datasource for tableView
    override func viewDidLoad {
        tableView.delegate = self
        tableView.dataSource = self
        
        retrieveData()
    }
    
    // Get UNFILTERED Data
    func retrieveData() {
    
        ref.observeSingleEventOfType(.Value, withBlock {snapshot in
            // Do all your Firebase Snapshot Retrieval Part Here
        })
    }

}

extension ViewController: UISearchBarDelegate {

    // If Cancel Button is Tapped >> Clear Text and endEditing
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        searchBar.text = ""
        view.endEditing(true)
    }
    
    // If user types in or removes or adds any characters do this
    func searchBar(searchBar: UISearchBar, textDidChange searchText: String) {
        if searchBar.text!.characters.count >= 3 {
            // If searchBar.text has 3 or more characters, filter retrieved data
            filterRetrievedData(searchBar.text!)
        } else {
            // If searchBar.text has less than 3 characters, stick with unfiltered data
            retrieveData()
        }
    }
    
    // Filter Data
    func filterRetrievedData(searchTerm: String){
        
        // the number of 'Z's are close to the number of maximum characters searchTerm can have
        let endSearchTerm = "\(searchTerm)zzzzzzzzzzzzzzzzz"
    
        ref.queryOrderedByChild("names").queryStartingAtValue(searchTerm).queryEndingAtValue(endSearchTerm).observeEventType(.Value, withBlock: { snapshot in
            
            // Retrieve Snapshot [PSST: It should be the same as the way you did above]
        
        })
        
        // Now you should get everything that starts with the 'searchTerm'
        
    }
    
}


